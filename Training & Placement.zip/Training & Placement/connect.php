<?php
$fname = $_POST'fname'];
$lname = $_POST'lname'];
$father = $_POST'father'];
$gender = $_POST'gender'];
$email = $_POST'email'];
$number = $_POST'number'];
$qualification = $_POST'qualification'];
$college = $_POST'college'];
$passing = $_POST'passing'];
$number = $_POST'number'];
$add = $_POST'add'];
$skill = $_POST'skill'];
$filename = $_POST'filename'];
//database connection
$conn = new mysqli('localhost','root','test');
if($conn->connect_error){
     die('Connection Failed :'.$conn->connect_error);
}else{
      $stmt = $conn->prepare("insert into registration(fname,lname,father,gender,email,number,qualification,college,passing,number,add,skill,filename)
          values(?,?,?,?,?,?,?,?,?,?,?,?,?) ")
      $stmt->bind param("sssssisssisss",$fname,$lname,$father,$gender,$email,$number,$qualification,$college,$passing,$number,$add,$skill,$filename);
      $stmt->excute();
      echo "Registration successfully...";
      $stmt->close();
      $conn->close();
}